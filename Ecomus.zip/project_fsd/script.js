
document.addEventListener("DOMContentLoaded", function() {
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('modal') === 'login') {
        var loginModal = new bootstrap.Modal(document.getElementById('loginModal'));
        loginModal.show();
    }
});

document.addEventListener("DOMContentLoaded", function() {
    const modal = document.querySelector(".cart-popup-modal-overlay");
    const productName = document.getElementById("product-name");
    const productPrice = document.getElementById("product-price");
    const productImage = document.getElementById("product-image");
    const totalPrice = document.getElementById("total-price");
    const colorOptions = document.getElementById("color-options");
    const selectedColor = document.getElementById("selected-color");

    document.querySelectorAll(".open-modal").forEach(button => {
        button.addEventListener("click", function() {
            const card = this.closest(".product-card");

            // Set modal data
            productName.textContent = card.dataset.name;
            productPrice.textContent = card.dataset.price;
            totalPrice.textContent = card.dataset.price;
            productImage.src = card.dataset.image;

            // Set colors dynamically
            colorOptions.innerHTML = "";
            const colors = card.dataset.colors.split(",");
            colors.forEach(color => {
                let colorButton = document.createElement("button");
                colorButton.classList.add("color-option");
                colorButton.style.backgroundColor = color.toLowerCase();
                colorButton.onclick = () => selectColor(color);
                colorOptions.appendChild(colorButton);
            });

            // Select first color by default
            selectedColor.textContent = colors[0];

            modal.style.display = "block";
        });
    });

    document.querySelector(".cart-popup-close-button").addEventListener("click", function() {
        modal.style.display = "none";
    });

    window.addEventListener("click", function(event) {
        if (event.target === modal) {
            modal.style.display = "none";
        }
    });
});

function selectColor(color) {
    document.getElementById("selected-color").textContent = color;
}

function selectSize(size) {
    document.getElementById("selected-size").textContent = size;
    document.querySelectorAll('.size-option').forEach(button => {
        button.classList.remove('active');
    });
    event.target.classList.add('active');
}

function increaseQuantity() {
    let quantityElement = document.getElementById("quantity").querySelector("b");
    let quantity = parseInt(quantityElement.textContent);
    quantityElement.textContent = quantity + 1;
    updateTotalPrice(quantity + 1);
}

function decreaseQuantity() {
    let quantityElement = document.getElementById("quantity").querySelector("b");
    let quantity = parseInt(quantityElement.textContent);
    if (quantity > 1) {
        quantityElement.textContent = quantity - 1;
        updateTotalPrice(quantity - 1);
    }
}

function updateTotalPrice(quantity) {
    let basePrice = parseFloat(document.getElementById("product-price").textContent.replace("₹", "").replace(",", "."));
    document.getElementById("total-price").textContent = "₹" + (basePrice * quantity).toFixed(2).replace(".", ",");
}

document.addEventListener("DOMContentLoaded", function() {
    const modalOverlay = document.querySelector(".cart-popup-modal-overlay");
    const closeButton = document.querySelector(".cart-popup-close-button");
    const openButtons = document.querySelectorAll(".eye-button"); // Assuming multiple eye buttons

    openButtons.forEach(button => {
        button.addEventListener("click", function() {
            modalOverlay.style.display = "flex";
        });
    });

    closeButton.addEventListener("click", function() {
        modalOverlay.style.display = "none";
    });

    modalOverlay.addEventListener("click", function(event) {
        if (event.target === modalOverlay) {
            modalOverlay.style.display = "none";
        }
    });

    // Quantity controls
    const quantityDisplay = document.getElementById("quantity");
    const totalPriceDisplay = document.getElementById("total-price");
    const productPrice = 1400; 

    function updateTotalPrice() {
        totalPriceDisplay.textContent = `₹${(parseInt(quantityDisplay.textContent) * productPrice).toFixed(2)}`;
    }

    document.querySelector(".cart-popup-quantity-controls button:first-child").addEventListener("click", function() {
        let quantity = parseInt(quantityDisplay.textContent);
        if (quantity > 1) {
            quantityDisplay.textContent = quantity - 1;
            updateTotalPrice();
        }
    });

    document.querySelector(".cart-popup-quantity-controls button:last-child").addEventListener("click", function() {
        let quantity = parseInt(quantityDisplay.textContent);
        quantityDisplay.textContent = quantity + 1;
        updateTotalPrice();
    });

    updateTotalPrice();
});


// open model
function openModal(icon) {
    const card = icon.closest(".card"); 

    // Get product details from data attributes
    const productName = card.dataset.name;
    const productPrice = card.dataset.price;
    const productImage = card.dataset.image;

    // Update modal content
    document.getElementById("product-name").textContent = productName;
    document.getElementById("product-price").textContent = productPrice;
    document.getElementById("total-price").textContent = productPrice;
    document.getElementById("product-image").src = productImage;

    // Extract color options
    const colors = [...card.querySelectorAll(".color-circle")].map(span => span.title);
    const colorOptions = document.getElementById("color-options");
    colorOptions.innerHTML = "";  // Clear previous colors

    colors.forEach(color => {
        let colorButton = document.createElement("button");
        colorButton.classList.add("color-option");
        colorButton.style.backgroundColor = color.toLowerCase();
        colorButton.onclick = () => selectColor(color);
        colorOptions.appendChild(colorButton);
    });

    // Select first color by default
    document.getElementById("selected-color").textContent = colors[0];

    // Show modal
    document.querySelector(".cart-popup-modal-overlay").style.display = "block";
}

// Close Modal Function
function closeModal() {
    document.querySelector(".cart-popup-modal-overlay").style.display = "none";
}

// Color Selection
function selectColor(color) {
    document.getElementById("selected-color").textContent = color;
}

// Size Selection
function selectSize(size) {
    document.getElementById("selected-size").textContent = size;
    document.querySelectorAll('.size-option').forEach(button => {
        button.classList.remove('active');
    });
    event.target.classList.add('active');
}

// Quantity Functions
function increaseQuantity() {
    let quantityElement = document.getElementById("quantity").querySelector("b");
    let quantity = parseInt(quantityElement.textContent);
    quantityElement.textContent = quantity + 1;
    updateTotalPrice(quantity + 1);
}

function decreaseQuantity() {
    let quantityElement = document.getElementById("quantity").querySelector("b");
    let quantity = parseInt(quantityElement.textContent);
    if (quantity > 1) {
        quantityElement.textContent = quantity - 1;
        updateTotalPrice(quantity - 1);
    }
}

// Update Total Price
function updateTotalPrice(quantity) {
    let basePrice = parseFloat(document.getElementById("product-price").textContent.replace("₹", ""));
    document.getElementById("total-price").textContent = "₹" + (basePrice * quantity).toFixed(2);
}









